<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Banner extends Model
{
    
    protected $fillable = [
        'banner_name'
    ];

    protected $table = "commn_bajaj_life";
}
