<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Banner;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->banner_table();
        $this->product_table();
        $this->brand_table();


    }

    public function banner_table() {

    	DB::table('banner')->delete();
 		
 		$banner_name = [

 			['banner_name' => 'banner1.jpeg']

 		];

        DB::table('banner')->insert($banner_name);
 
        $this->command->info('banner table seeded!');
    }

    public function product_table() {

    	DB::table('product')->delete();
 		
 		$product_name = [

 			['product_name' => 'product-1.jpeg', 'collection_name' => 'Product 1'],
 			['product_name' => 'product-2.jpeg', 'collection_name' => 'Product 2'],
 			['product_name' => 'product-3.jpeg', 'collection_name' => 'Product 3'],
 			['product_name' => 'product-4.jpeg', 'collection_name' => 'Product 4'],
 			['product_name' => 'product-5.jpeg', 'collection_name' => 'Product 5'],
 			['product_name' => 'product-6.jpeg', 'collection_name' => 'Product 6'],
 			['product_name' => 'product-7.jpeg', 'collection_name' => 'Product 7'],
 			['product_name' => 'product-8.jpeg', 'collection_name' => 'Product 8'],
 			['product_name' => 'product-9.jpeg', 'collection_name' => 'Product 9'],
 			['product_name' => 'product-10.jpeg', 'collection_name' => 'Product 10'],
 			['product_name' => 'product-11.jpeg', 'collection_name' => 'Product 11'],
 			['product_name' => 'product-12.jpeg', 'collection_name' => 'Product 12'],

 		];

        DB::table('product')->insert($product_name);
 
        $this->command->info('product table seeded!');
    }

    public function brand_table() {

        DB::table('brand')->delete();
        
        $brand_name = [

            ['brand_img' => 'brand-1.png', 'brand_name' => 'Brand 1'],
            ['brand_img' => 'brand-2.png', 'brand_name' => 'Brand 2'],
            ['brand_img' => 'brand-3.png', 'brand_name' => 'Brand 3']
        ];

        DB::table('brand')->insert($brand_name);
 
        $this->command->info('brand table seeded!');
    }
}
