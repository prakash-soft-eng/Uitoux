<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Role;
use Illuminate\Support\Facades\DB;

class Home_controller extends Controller
{
    
    public function get_banner_details() {

    	$res = array();
    	$get_details = DB::table('banner')
    					->select('banner_name', 'id')
    					->get();
    	if(count($get_details) > 0) {
    		$res = $get_details;
    	} 
    	return json_encode($get_details);
    } 

    public function get_product_details() {

    	

        $product_details = $this->get_product();
        $brand_details = $this->get_brand();
        
        return view('Home',compact('product_details','brand_details'));

    }


    public function get_product() {

        $product_details = array();
        $get_details = DB::table('product')
                        ->select('product_name', 'id','collection_name')
                        ->get();
        if(count($get_details) > 0) {
            $product_details = $get_details;
        }

        return $product_details;
    }

    public function get_brand() {

        $brand_details = array();
        $get_details = DB::table('brand')
                        ->select('brand_img', 'id','brand_name')
                        ->get();
        if(count($get_details) > 0) {
            $brand_details = $get_details;
        }

        return $brand_details;

    }
}
